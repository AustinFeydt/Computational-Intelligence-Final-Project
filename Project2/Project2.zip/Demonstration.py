import Exercise1 as ex1 
import Exercise2 as ex2 
import Exercise3 as ex3 
ex1_results = ex1.demonstrations()
ex2.demonstrations(ex1_results)
ex3.demonstrations(ex1_results)